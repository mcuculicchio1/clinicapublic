<?php
$file_autoload = "../App/autoload.php";
if(file_exists($file_autoload)){
    require_once($file_autoload);
}else{
    $file_autoload = "../$file_autoload";
    if(file_exists($file_autoload)){
        require_once($file_autoload);
    }
}
// constantes para el log
const ERROR = 100;
const INFO = 300;
const DEBUG = 200;
//ubicacion log
const ARCHIVOLOG = "clinica.log";

//ubicacion pages
const DIR_PAGES = "../App/Pages/";


