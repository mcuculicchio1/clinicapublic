<?php

namespace App\Dao;
include_once('db.php');
class Dao_anexa{
    
    //metodo de paises
    static function get_paises(Array $filtro=[]): array
    {
        $where = "1=1";
        if(isset($filtro['id']))
            $where .= " AND id=".$filtro['id'];
        if(isset($filtro['nombre']))
            $where .= " AND nombre LIKE '%".$filtro['nombre']."%'";
        $sql = "SELECT * FROM paises WHERE $where order by nombre";
        db::ejecutar($sql);
        return db::get_datos();
    }
    //Metodos provincias
    static function get_provincias(Array $filtro=[]): array
    {
        $where = "1=1";
        if(isset($filtro['id']))
            $where .= " AND id=".$filtro['id'];
        if(isset($filtro['nombre']))
            $where .= " AND nombre LIKE '%".$filtro['nombre']."%'";
            if(isset($filtro['pais_id']))
                $where .= " AND pais_id=".$filtro['pais_id'];
        $sql = "SELECT * FROM provincias WHERE $where order by nombre";
        db::ejecutar($sql);
        return db::get_datos();
    }
    //Metodos ciudades
    static function get_ciudades(Array $filtro=[]): array
    {
        $where = "1=1";
        if(isset($filtro['id']))
            $where .= " AND id=".$filtro['id'];
        if(isset($filtro['nombre']))
            $where .= " AND nombre LIKE '%".$filtro['nombre']."%'";
            if(isset($filtro['provincia_id']))
                $where .= " AND provincia_id=".$filtro['provincia_id'];
        $sql = "SELECT * FROM ciudades WHERE $where order by nombre";
        db::ejecutar($sql);
        return db::get_datos();
    }
    //metodos de obra social
    static function get_obras_sociales(Array $filtro=[]): array
    {
        $where = "1=1";
        if(isset($filtro['id']))
        $where .= " AND id=".$filtro['id'];
        if(isset($filtro['nombre']))
        $where .= " AND nombre LIKE '%".$filtro['nombre']."%'";
        $sql = "SELECT * FROM listado_obra_sociales WHERE $where order by nombre";
        db::ejecutar($sql);
        return db::get_datos();
    }
    //metodos de tipos de documento
    static function get_tipos_documento(): array
    {
        $sql = "SELECT * FROM tipos_documentos";
        db::ejecutar($sql);
        return db::get_datos();
    }
    //metodos de perfiles
    static function get_perfiles(): array
    {
        $sql = "SELECT * FROM perfiles";
        db::ejecutar($sql);
        return db::get_datos();
    }
// static function get_pais_id(int $id): array
// {
    //     $sql = "SELECT * FROM paises WHERE id=$id";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    // static function get_pais_nombre(string $nombre): array
        // {
        //     $sql = "SELECT * FROM paises WHERE nombre='$nombre'";
        //     db::ejecutar($sql);
        //     return db::get_datos();
        // }
        //Metodos provincias

    
    // static function get_ciudades_por_provincia(int $provincia_id): array {
    //     $sql = "SELECT * FROM ciudades WHERE provincia_id=$provincia_id order by nombre";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }

    
    // static function get_obra_social_nombre_filtro(string $nombre): array
    // {
    //     $sql = "SELECT * FROM listado_obra_sociales WHERE nombre LIKE '%$nombre%'";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    // static function get_obra_social(int $id): array
    // {
    //     $sql = "SELECT * FROM listado_obra_sociales WHERE id=$id";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    // static function get_pais_nombre_filtro(string $nombre): array
    // {
        //     $sql = "SELECT * FROM paises WHERE nombre LIKE '%$nombre%'";
        //     db::ejecutar($sql);
        //     return db::get_datos();
        // }
        


        // static function get_provincias_por_pais(int $pais_id): array {
        //     $sql = "SELECT * FROM provincias WHERE pais_id=$pais_id";
        //     db::ejecutar($sql);
        //     return db::get_datos();
        // }

    //     static function get_provincia_nombre_filtro(string $nombre): array
    //     {
    //         $sql = "SELECT * FROM provincias WHERE nombre LIKE '%$nombre%'";
    //         db::ejecutar($sql);
    //         return db::get_datos();
    //     }
        
    //     static function get_provincia_id(int $id): array
    //     {
    //         $sql = "SELECT * FROM provincias WHERE id=$id";
    //         db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    // static function get_provincia_nombre(string $nombre): array
    // {
    //     $sql = "SELECT * FROM provincias WHERE nombre='$nombre'";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    
    // static function get_tipo_documento_id(int $id): array
    // {
    //     $sql = "SELECT * FROM tipos_documentos WHERE id=$id";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    // static function get_tipo_documento_nombre(string $nombre): array
    // {
    //     $sql = "SELECT * FROM tipos_documentos WHERE nombre='$nombre'";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    
    // static function get_perfil_id(int $id): array
    // {
    //     $sql = "SELECT * FROM perfiles WHERE id=$id";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    // static function get_perfil_nombre(string $nombre): array
    // {
    //     $sql = "SELECT * FROM perfiles WHERE nombre='$nombre'";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    // static function get_ciudad_id(int $id): array
    // {
    //     $sql = "SELECT * FROM ciudades WHERE id=$id";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    // static function get_ciudad_nombre(string $nombre): array
    // {
    //     $sql = "SELECT * FROM ciudades WHERE nombre='$nombre'";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
    
    // static function get_ciudad_nombre_filtro(string $nombre): array
    // {
    //     $sql = "SELECT * FROM ciudades WHERE nombre LIKE '%$nombre%'";
    //     db::ejecutar($sql);
    //     return db::get_datos();
    // }
}