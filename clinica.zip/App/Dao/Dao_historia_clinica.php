<?php
namespace App\Dao;

class Dao_historia_clinica {

//Agregar nueva historia clinica
    static function nuevaHistoriaClinica(array $datos){
        $sql = <<<SQL
        INSERT INTO historias_clinicas(
            paciente,
            profesional,
            fecha,
            descripcion,
            etiquetas
        ) 
        VALUES(
            '$datos[paciente]',
            '$datos[profesional]',
            '$datos[fecha]',
            '$datos[descripcion]',
            '$datos[etiquetas]'
        );
        SQL;
        return db::ejecutar($sql);
    }

    //Recuperar datos de las historias clinicas
    static function getDatosHistorias(array $filtro=[]): array
     {
        $where = "1=1";

        if(isset($filtro['descripcion']))
            $where .= " AND descripcion LIKE '%".$filtro['descripcion']."%'";

        if(isset($filtro['etiquetas']))
            $where .= " AND etiquetas LIKE '%".$filtro['etiquetas']."%'";

        if(isset($filtro['paciente']))
            $where .= " AND paciente=".$filtro['paciente'];
           
        if(isset($filtro['fecha']))
        $where .= " AND fecha=".$filtro['fecha'];        

        $sql = "SELECT * FROM historias_clinicas WHERE ".$where;
        db::ejecutar($sql);
        return db::get_datos();
    }

    //Actualizar historia clinica

    static function updateHistoriaClinica(array $datos): bool
    {
        $sql = <<<SQL
        UPDATE historias_clinicas SET
            paciente = '$datos[paciente]',
            profesional = '$datos[profesional]',
            fecha = '$datos[fecha]',
            descripcion = '$datos[descripcion]',
            etiquetas = '$datos[etiquetas]'
        WHERE id = $datos[id]
        SQL;
        return db::ejecutar($sql);
    }

    //eliminar historia clinica
    static function deleteHistoriaClinica(int $id): bool
    {
        $sql = "DELETE FROM historias_clinicas WHERE id=".$id;
        return db::ejecutar($sql);
    }
    
    
}