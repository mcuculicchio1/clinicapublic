<?php
namespace App\Dao;

class Dao_paciente{

    //agregar un nuevo paciente

    static function nuevoPaciente(array $datos){
        $sql = <<<SQL
        INSERT INTO pacientes (
            nombre,
            apellido,
            docu_num,
            docu_tipo,
            fecha_nac,
            ciudad,
            domicilio,
            telefono,
            email,
            os_tipo,
            os_afiliado
        ) VALUES (
            '$datos[nombre]',
            '$datos[apellido]',
            '$datos[docu_num]',
            '$datos[docu_tipo]',
            '$datos[fecha_nac]',
            '$datos[ciudad]',
            '$datos[domicilio]',
            '$datos[telefono]',
            '$datos[email]',
            '$datos[os_tipo]',
            '$datos[os_afiliado]'
        )
        SQL;
        return db::ejecutar($sql);
    }

    //Recuperar datos de los pacientes
    static function getDatosPacientes(array $filtro=[]): array
     {
        $where = "1=1";

        if(isset($filtro['apellido']))
            $where .= " AND apellido LIKE '%".$filtro['apellido']."%'";

        if(isset($filtro['nombre']))
            $where .= " AND nombre LIKE '%".$filtro['nombre']."%'";

        if(isset($filtro['docu_num']))
            $where .= " AND docu_num=".$filtro['docu_num'];
           
        if(isset($filtro['telefono']))
        $where .= " AND telefono=".$filtro['telefono'];        

        $sql = "SELECT * FROM pacientes WHERE ".$where;
        db::ejecutar($sql);
        return db::get_datos();
    }

    //recuperar lista de pacientes

    static function getLista(): array
    {
        $sql = "SELECT * FROM pacientes ORDER BY apellido, nombre";
        db::ejecutar($sql);
        return db::get_datos();
    }

    // Recuperar datos de un paciente
    static function getDatosPaciente(int $id): array
    {
        $sql = "SELECT * FROM pacientes WHERE id=".$id;
        db::ejecutar($sql);
        return db::get_datos()[0];
    }

    //Actualizar datos de un paciente

    static function actualizarPaciente(array $datos, $id) {
        $sql = <<<SQL
        UPDATE pacientes SET
            nombre = '$datos[nombre]',
            apellido = '$datos[apellido]',
            docu_num = '$datos[docu_num]',
            docu_tipo = '$datos[docu_tipo]',
            fecha_nac = '$datos[fecha_nac]',
            ciudad = '$datos[ciudad]',
            domicilio = '$datos[domicilio]',
            telefono = '$datos[telefono]',
            email = '$datos[email]',
            os_tipo = '$datos[os_tipo]',
            os_afiliado = '$datos[os_afiliado]'
        WHERE id = '$id'
        SQL;
    
        return db::ejecutar($sql);
    }
 //Eliminar un paciente
    static function eliminarPaciente($id) {
        $sql = <<<SQL
        DELETE FROM pacientes WHERE id = '$id'
        SQL;
    
        return db::ejecutar($sql);
    }
    
    

}