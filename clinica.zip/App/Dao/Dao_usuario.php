<?php
namespace App\Dao;

class Dao_usuario
{
    /**
     * Agrega un nuevo usuario
     */
    static function nuevo(array $datos): bool
    {
        $sql = <<<SQL
        INSERT INTO usuarios (
            usuario,
            password,
            nombre,
            telefono,
            domicilio,
            docu_num,
            docu_tipo,
            perfil
        ) VALUES (
            '$datos[usuario]',
            '$datos[password]',
            '$datos[nombre]',
            '$datos[telefono]',
            '$datos[domicilio]',
            '$datos[docu_num]',
            '$datos[docu_tipo]',
            '$datos[perfil]'
        )
    SQL;
        return db::ejecutar($sql);
    }

    //obtener usuario por nombre de usuario para login

    static function get_usuario(string $usuario): array {
        $sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
        db::ejecutar($sql);
        $datos = db::get_datos();
        return $datos ? $datos[0] : [];
    }

    //obtener contraseña de un usuario

    static function get_password(string $usuario): string {
        $sql = "SELECT password FROM usuarios WHERE usuario = '$usuario'";
        db::ejecutar($sql);
        $datos = db::get_datos();
        return $datos ? $datos[0]['password'] : '';
    }

    /**
     * Recupera los datos de los usuarios
     */

     static function get_datos(array $filtro=[]): array
     {
        $where = "1=1";

        if(isset($filtro['usuario']))
            $where .= " AND usuario='".$filtro['usuario']."'";

        if(isset($filtro['nombre']))
            $where .= " AND nombre LIKE '%".$filtro['nombre']."%'";

        if(isset($filtro['perfil']))
            $where .= " AND perfil=".$filtro['perfil'];

        $sql = "SELECT * FROM usuarios WHERE ".$where;
        db::ejecutar($sql);
        return db::get_datos();
    }


    /**
     * Perfil de un usuario
     */
    static function get_perfil(string $usuario): array
    {
        $sql = "SELECT p.nombre as perfil
                FROM perfiles p, usuario u 
                WHERE u.usuario='".$usuario."'
                    AND p.id=u.perfil;";

        db::ejecutar($sql);
        return db::get_datos();     
    }

    //Actualizar datos de un usuario

    static function update(array $datos): bool
    {
        $sql = <<<SQL
        UPDATE usuarios SET
            usuario='$datos[usuario]',
            password='$datos[password]',
            nombre='$datos[nombre]',
            telefono='$datos[telefono]',
            domicilio='$datos[domicilio]',
            docu_num='$datos[docu_num]',
            docu_tipo='$datos[docu_tipo]',
            perfil='$datos[perfil]'
        WHERE id=$datos[id]
    SQL;
        return db::ejecutar($sql);
    }

    //Eliminar un usuario

    static function delete(int $id): bool
    {
        $sql = "DELETE FROM usuarios WHERE id=".$id;
        return db::ejecutar($sql);
    }
}