<?php
namespace App\Dao;
use App\Lib\Log;

class db
{
 
    protected static $conexion = null;
    
 
    /**
     * Establece la conexión a la base de datos clinica
     */
    
    static function get_conexion()
    {
        $mensaje="";
        try{
        
        if(is_null(self::$conexion))
            self::$conexion = mysqli_connect('localhost','usr_cnel_pringles','pringles.2024','clinica');
    
        if(!self::$conexion)
            echo mysqli_connect_error();
        
        return self::$conexion;
        }
        catch(\Exception $e)
        {   
            Log::grabar("[ERROR]".PHP_EOL.$e->getMessage().PHP_EOL.$e->getCode());
            throw new \Exception(ERROR);
        }
    }

    /**
     * ejecuta una sentencia SQL
     */
    static function ejecutar(string $sql)
    {
        $rs = mysqli_multi_query(self::get_conexion(), $sql);
        if(!$rs)
            echo mysqli_error(self::get_conexion());
        return $rs;
    }

    /**
     * Recuperar los datos de un SELECT
     */
    static function get_datos(): array
    {
        $datos = [];
        $rs = mysqli_store_result(self::get_conexion());
        if($rs)
            $datos = mysqli_fetch_all($rs, MYSQLI_ASSOC);
        mysqli_free_result($rs);
        return $datos;
    }
}