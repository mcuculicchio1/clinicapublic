<?php

namespace App\Lib;

class Log{

    //GRABAR MENSAJES EN EL ARCHIVO LOG
    static function grabar(string $mensaje)
    {
        $file = (ARCHIVOLOG !== null)? ARCHIVOLOG : 'clinica.log';
        file_put_contents($file, self::encabezado().$mensaje, FILE_APPEND);
    }

    //METODO ENCABEZADO DEL LOG

    private static function encabezado(): string   //va a devolver un string
    {
        $str = PHP_EOL.PHP_EOL; //$str variable abreviando el nombre string PHP_EOL ( SALTO DE LINEA)
        $str .="+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-++-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+.".PHP_EOL;
        $str .="+ ". date('Y-m-d H:m:s').PHP_EOL."+";  //fecha y hora
        $str .= " ".__FILE__.PHP_EOL."+ "; //__FILE__  devuelve la ruta del archivo
        $str .= (isset($_SERVER['REQUEST_URI']))? $_SERVER['REQUEST_URI'].PHP_EOL : ''; //$_SERVER['REQUEST_URI'] devuelve la url
        $str .= "+ "."######################################################################################################".PHP_EOL;
        return $str;
    }

    
    static function set_archivo_log(string $ruta)
    {
        $ruta_archivo = $ruta;
        file_put_contents($ruta_archivo,self::encabezado(),FILE_APPEND);
    }
    static function ver(mixed $dato)
    {
        echo '<pre>';
        print_r($dato);
        echo '</pre>';
    }
}
