<?php

namespace App\Lib;

class Page{
    //Recupera una pagina desde la url, indicada en el parametro p (get)

    static function get(): string
    {
        $page = filter_input(INPUT_GET, 'p');
        if(file_exists(DIR_PAGES.$page.".php"))
        {
          $page = DIR_PAGES.$page.".php";
        }else{
            $page = "";
        }
        return $page;
    }
  
    //Establece la pagina a pasar por p (get), si viene vacio, se establece en index
    static function set(string $page=""): string
    {
        
        return ($page)? "index.php?p=$page" : "index.php";
    }
}