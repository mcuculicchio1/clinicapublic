<?php
use App\Dao\Dao_anexa;

$mensaje = "";

// Cargar países y otros datos para los selectores
$paises = Dao_anexa::get_paises();
$obras_sociales = Dao_anexa::get_obras_sociales();
$tipos_documento = Dao_anexa::get_tipos_documento();

?>

<div class="container">
        <h1 class="mt-5">Alta de Pacientes</h1>
        <form id="form-alta-paciente" action="" method="post">
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>
            <div class="form-group">
                <label for="apellido">Apellido</label>
                <input type="text" class="form-control" id="apellido" name="apellido" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="fecha_nacimiento">Fecha de Nacimiento</label>
                <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" required>
            </div>
            <div class="form-group">
                <label for="pais">País</label>
                <select class="form-control" id="pais" name="pais" required>
                    <option value="54">Seleccione un país</option>
                    <?php foreach ($paises as $pais): ?>
                        <option value="<?= $pais['id'] ?>"><?= $pais['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="provincia">Provincia</label>
                <select class="form-control" id="provincia" name="provincia" required>
                    <option value="">Seleccione una provincia</option>
                </select>
            </div>
            <div class="form-group">
                <label for="ciudad">Ciudad</label>
                <select class="form-control" id="ciudad" name="ciudad" required>
                    <option value="">Seleccione una ciudad</option>
                </select>
            </div>
            <div class="form-group">
                <label for="obra_social">Obra Social</label>
                <select class="form-control" id="obra_social" name="obra_social">
                    <option value="">Seleccione una obra social</option>
                    <?php foreach ($obras_sociales as $obra): ?>
                        <option value="<?= $obra['id'] ?>"><?= $obra['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="tipo_documento">Tipo de Documento</label>
                <select class="form-control" id="tipo_documento" name="tipo_documento">
                    <option value="">Seleccione un tipo de documento</option>
                    <?php foreach ($tipos_documento as $tipo): ?>
                        <option value="<?= $tipo['id'] ?>"><?= $tipo['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="numero_documento">Número de Documento</label>
                <input type="text" class="form-control" id="numero_documento" name="numero_documento" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>