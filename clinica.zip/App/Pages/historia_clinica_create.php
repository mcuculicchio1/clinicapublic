<?php
//$script = "historia_clinica_create.js";
use App\Dao\Dao_historia_clinica;
use App\Lib\Log;
use App\Dao\Dao_paciente;

$mensaje = "";
if($_POST){
    $datos = [
        'paciente' => $_POST['paciente'],
        'profesional' => $_POST['profesional'],
        'descripcion' => $_POST['descripcion'],
        'etiquetas' => $_POST['etiquetas'],
        'fecha' => date('Y-m-d')
    ];
    try{
        Dao_historia_clinica::nuevaHistoriaClinica($datos);
        $mensaje = "Historia clinica guardada";
       // echo $mensaje;

    }
    catch(Exception | ERROR $e){
        $mensaje = "Error al guardar la historia clinica:";
        echo $mensaje;
        Log::grabar("[ERROR]".$mensaje.$e->getCode().PHP_EOL.$e->getMessage());
    }


    
}

?>
<form action="" method="post" onsubmit="return validarFormulario();">
    <div class="mb3">
    <select class="form-select" aria-label="Default select example" name="paciente" id="paciente" require>
        <option selected>Paciente</option>
        <?php
        $pacientes = Dao_paciente::getLista();
        foreach ($pacientes as $paciente): ?>
                        <option value="<?= $paciente['id'] ?>"><?= $paciente['nombre'] ?></option>
                    <?php endforeach; ?>
    </select>
    </div>
    <div class="mb3">
        <label for="profesional">Profesional</label>
        <input type="text" class="form-control" id="profesional" name="profesional" require>
    </div>
    <div class="mb3">
        <label for="descripcion">Descripcion</label>
        <textarea class="form-control" id="descripcion" name="descripcion" require></textarea>
    </div>
    <div class="mb3">
        <label for="etiquetas">Etiquetas</label>
        <input type="text" class="form-control" id="etiquetas" name="etiquetas">
    </div>
    
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>

