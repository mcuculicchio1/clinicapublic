
<form action="servicios/procesar_login.php" method="POST">
<section class="vh-100" style="background-color: #508bfc;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card shadow-2-strong" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

            <h3 class="mb-5">Inicio de sesion</h3>

            <div data-mdb-input-init class="form-outline mb-4">
              <input type="text" id="usuario" name="usuario" class="form-control form-control-lg" />
              <label class="form-label" for="usuario">Usuario</label>
            </div>

            <div data-mdb-input-init class="form-outline mb-4">
              <input type="password" id="contraseña" name="contraseña" class="form-control form-control-lg" />
              <label class="form-label" for="contraseña">Contraseña</label>
            </div>


            <button data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-lg btn-block" type="submit">Login</button>

            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</form>

