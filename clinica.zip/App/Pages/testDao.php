<?php
use App\Dao\Dao_historia_clinica;
use App\Lib\Log;
use App\Dao\Dao_paciente;
use App\Dao\Dao_anexa;
$mensaje = "";

if ($_POST) {
    $datos = [
        'paciente' => $_POST['paciente'],
        'profesional' => $_POST['profesional'],
        'descripcion' => $_POST['descripcion'],
        'etiquetas' => $_POST['etiquetas'],
        'fecha' => date('Y-m-d')
    ];
    try {
        Dao_historia_clinica::nuevaHistoriaClinica($datos);
        $mensaje = "La consulta se grabó de forma satisfactoria.";
    } catch (Exception | ERROR $e) {
        $mensaje = "Se produjo un error al grabar la consulta: " . $e->getMessage();
        Log::grabar("[ERROR] " . $e->getCode() . " " . $e->getMessage());
    }
}

$pacientes = Dao_paciente::getLista(); // Obtener pacientes de la base de datos
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cargar Consulta Clínica</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script>
        function validarFormulario() {
            const paciente = document.getElementById('paciente').value;
            const profesional = document.getElementById('profesional').value;
            const descripcion = document.getElementById('descripcion').value;
            const etiquetas = document.getElementById('etiquetas').value;

            if (!paciente || !profesional || !descripcion || !etiquetas) {
                alert("Todos los campos son obligatorios.");
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <h1>
        <?php
        $filtro=["id"=>54];
         $pais= Dao_anexa::get_paises($filtro);
        var_dump($pais) ; ?>
    </h1>
    <div class="container">
        <h1 class="mt-5">Cargar Consulta Clínica</h1>
        <?php if ($mensaje): ?>
            <div class="alert alert-info">
                <?= $mensaje ?>
            </div>
        <?php endif; ?>
        <form action="" method="post" onsubmit="return validarFormulario();">
            <div class="form-group">
                <label for="paciente">Paciente</label>
                <select class="form-control" name="paciente" id="paciente">
                    <option value="">Seleccione un paciente</option>
                    <?php foreach ($pacientes as $paciente): ?>
                        <option value="<?= $paciente['id'] ?>"><?= $paciente['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="profesional">Profesional</label>
                <input type="text" class="form-control" id="profesional" name="profesional" value="Profesional Fijo">
            </div>
            <div class="form-group">
                <label for="descripcion">Descripción</label>
                <textarea class="form-control" id="descripcion" name="descripcion"></textarea>
            </div>
            <div class="form-group">
                <label for="etiquetas">Etiquetas</label>
                <input type="text" class="form-control" id="etiquetas" name="etiquetas">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
</body>
</html>
