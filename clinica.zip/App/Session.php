<?php
namespace App;

class Session{

    private static $sesion_iniciada = false;

    function __construct()
    {
        if(!self::$sesion_iniciada)
        {
        
            
            session_name('clinica');  // nombre de la cookie

            $secure = false; // Solo se envía a través de HTTPS
            $httponly = true; // No accesible por JavaScript
            $samesite = 'Strict'; // Evita el envío en solicitudes cross-site
            $maxlifetime = 120; // La cookie dura hasta que se cierra el navegador

            if(PHP_VERSION_ID < 70300)   // version de PHP < 7.3
            {
                session_set_cookie_params($maxlifetime, '/; samesite='.$samesite,$_SERVER['HTTP_HOST'], $secure, $httponly);
            }
            else
            {
                session_set_cookie_params([
                    'lifetime' => $maxlifetime,
                    'path' => '/',
                    'domain' => $_SERVER['HTTP_HOST'],
                    'secure' => $secure,
                    'httponly' => $httponly,
                    'samesite' => $samesite
                ]);
            }
            session_start();
            self::$sesion_iniciada = true;
        }
    }

    static function iniciada() : bool  // devuelve true si la sesion esta iniciada
    {
        return self::$sesion_iniciada;
        
    }

    function set(string $nombre, $valor)
    {
        if(self::$sesion_iniciada)
        {
            $_SESSION[$nombre] = $valor;
        }
    }

    function get(string $nombre): mixed  // obtiene una variable de sesion
    {
       if(self::$sesion_iniciada && isset($_SESSION[$nombre]))
       {
           return $_SESSION[$nombre];
       }
         return null;
    }

    function get_id(): mixed  // obtiene el id de la sesion
    {
        if(self::$sesion_iniciada)
        {
            return session_id();
        }
        return null;
    }

    static function borrar(string $nombre)  // borra una variable de sesion
    {
        if(self::$sesion_iniciada && isset($_SESSION[$nombre]))
        {
            unset($_SESSION[$nombre]);
        }
    }

   static function cerrar()  // cierra la sesion
    {
      unset($_SESSION);
      self::$sesion_iniciada = false;
      return session_destroy();
    }

    
   
}