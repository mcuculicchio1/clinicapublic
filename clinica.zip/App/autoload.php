<?php

//Carga automatima de clases

// spl_autoload_register(function ($nombre_clase) {
//     $directorios = ['../Dao/', '../Lib/', '../Log', '../Pages'];

//     foreach ($directorios as $directorio) {
//         $archivo = $directorio . $nombre_clase . '.php';
        
//         if (file_exists($archivo)) {
//             require_once $archivo;
//             return;
//         }
//     }
// });

spl_autoload_register(function ($nombre_clase) {
    $archivo='../'.strtolower($nombre_clase).'.php';
    if(file_exists($archivo)){
        require_once($archivo);
    }else{
        $archivo='../'.$archivo;
        if(file_exists($archivo)){
            require_once($archivo);
        }
    }
});
