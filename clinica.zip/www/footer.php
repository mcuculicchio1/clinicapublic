<footer style="position: absolute;
  bottom: 0;
  width: 100%;
  height: 2.5rem;
  background-color: blue;
  text-align:center">
    <div class="container">
        <h2>footer</h2>
    </div>
</footer>