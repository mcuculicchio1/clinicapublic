<!DOCTYPE html>
<html lang="Es">
<?php 
  use App\Session;
  use App\Lib\Page;
  use App\Lib\Log;
  
  include_once('../App/autoload.php');
  include_once('../App/Config.php');
  include_once('../App/Lib/Page.php');  
  include_once('head.php');
?>
<body>
    <div style="position: relative; min-height: 100vh;">
    <?php 
        Log::set_archivo_log('../App/Log/'.ARCHIVOLOG);
   
        try {
            $session = new Session();
            var_dump($session->get('login'));  // Depuración: ver valor de login
        ?>
        
        <?php if(!$session->get('login')): ?>
            <?php
            echo "No estás logueado. Cargando login...";  // Mensaje de depuración
            $page = Page::get('login');
            var_dump($page);  // Verificar la ruta de la página de login
            if ($page) {
                include_once($page);  // Incluir la página de login si existe
            } else {
                echo "No se encontró la página de login.";
            }
            ?>
        <?php else: ?>
            <?php 
            include_once('menu.php');  // Incluir el menú si estás logueado

            $page = Page::get();  // Obtener la página correspondiente
            var_dump($page);  // Depurar la página actual
            if ($page) {
                include_once($page);
            } else {
                echo "No se encontró la página solicitada.";
            }
            ?>
        <?php endif; ?>
        
    <?php
        } catch(Exception | ERROR $e) {
            switch($e->getCode()) {
                case ERROR:
                    echo "<h2 style='color:red;'>".$e->getMessage().PHP_EOL.$e->getCode()."</h2>";
                    Log::grabar("[ERROR]".PHP_EOL.$e->getMessage());
                    break;
                case DEBUG:
                    Log::grabar("[DEBUG]".PHP_EOL.$e->getMessage());
                    break;
                case INFO:
                    echo "<h2 style='color:blue;'>".$e->getMessage().PHP_EOL.$e->getCode()."</h2>";
                    Log::grabar("[INFO]".PHP_EOL.$e->getMessage());
                    break;    
                default:
                    echo "<h2 style='color: green;'>".$e->getMessage().PHP_EOL.$e->getCode()."</h2>";
                    Log::grabar("[WARNING]".PHP_EOL.$e->getMessage());
                    break;
            }
        }
    ?>
    </div>
    <?php include_once('footer.php'); ?>
</body>
</html>

