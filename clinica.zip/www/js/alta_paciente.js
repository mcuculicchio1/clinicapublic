import * as anexas from './anexas.js';

'use strict';

window.onload = function () {
    const pais = document.getElementById('pais');
    
    const provincia = document.getElementById('provincia');
    const ciudad = document.getElementById('ciudad');

    if (provincia) {
        pais.onchange = () => {
            const solicitud = {
                tabla: 'provincias',
                filtro: {
                    pais: (pais.value)
                }
            };
            alert(pais.value);
            anexas.solicitarDatos(solicitud)
                .then(mostrarProvincias)
                .catch(error => console.error('Error al cargar provincias', error));
        };

        provincia.onchange = () => {
            const solicitud = {
                tabla: 'ciudades',
                filtro: {
                    provincia: provincia.value
                }
            };

            anexas.solicitarDatos(solicitud)
                .then(mostrarCiudades)
                .catch(error => console.error('Error al cargar ciudades', error));
        };
    }

    function mostrarProvincias(datos) {
        if (!datos || datos.length === 0) {
            console.error('No hay datos para mostrar en la solicitud de provincias');
            return;
        }

        provincia.innerHTML = '<option value="">Seleccione una provincia</option>';
        ciudad.innerHTML = '<option value="">Seleccione una ciudad</option>';

        for (const dato of datos) {
            const option = document.createElement('option');
            option.value = dato.id;
            option.textContent = dato.nombre;
            provincia.appendChild(option);
        }
        provincia.disabled = false;
        ciudad.disabled = true;
    }

    function mostrarCiudades(datos) {
        if (!datos || datos.length === 0) {
            console.error('No hay datos para mostrar en la solicitud de ciudades');
            return;
        }

        ciudad.innerHTML = '<option value="">Seleccione una ciudad</option>';

        for (const dato of datos) {
            const option = document.createElement('option');
            option.value = dato.id;
            option.textContent = dato.nombre;
            ciudad.appendChild(option);
        }
        ciudad.disabled = false;
    }
};
