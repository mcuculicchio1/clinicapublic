import * as anexas from './anexas.js';

'use strict';

//recuperar datos del dom
onload = function () {
    const pais = document.getElementById('pais');
    const provincia = document.getElementById('provincia');
    const ciudad = document.getElementById('ciudad');
    this.alert(pais);

    // if (provincia)
    //     provincia.disabled = true;

     if (ciudad)
        ciudad.disabled = true;

    if (provincia) {
        const solicitud = {
            tabla: 'provincias',
            filtro: {
                pais: '54'
            } // filtro
        }; // solicitud

        anexas.solicitarDatos(solicitud)
            .then(mostrar)
            .catch(error);

        function mostrar(datos) {
            if (typeof datos == 'undefined')
                throw new Error('Hay un error en el tipo de datos');

            if (datos.length == 0)
                throw new Error('No hay datos para mostrar en la solicitud', { cause: solicitud });

            for (const dato of datos) {
                const option = document.createElement('option');
                option.value = dato.id;
                option.innerHTML = dato.nombre;
                provincia.appendChild(option);
            }
            provincia.disabled = false;

        } // funcion mostrar
        // si cambia el valor de pais, se actualiza el filtro de provincia
        pais.onchange = () => {
            const solicitud = {
                tabla: "provincias",
                filtro: {
                    pais: pais.value
                }
            }; // solicitud

           

            anexas.solicitarDatos(solicitud)
                .then(mostrar)
                .catch(error);

            function mostrar(datos) {
                if (typeof datos == 'undefined') {
                    throw new Error('Hay un error en el tipo de datos');
                }
                if (datos.length == 0) {
                    throw new Error('No hay datos para mostrar en la solicitud', { cause: solicitud });
                }
                provincia.innerHTML = '';
                ciudad.innerHTML = '';
                for (const dato of datos) {
                    const option = document.createElement('option');
                    option.value = dato.id;
                    option.innerHTML = dato.nombre;
                    provincia.appendChild(option);
                }
                provincia.disabled = false;
                ciudad.disabled = true;
            } // funcion mostrar

        } // pais.onchange

        provincia.onchange = () => {
            const solicitud = {
                tabla: 'ciudades',
                filtro: {
                    provincia: provincia.value
                }
            }; // solicitud

            anexas.solicitarDatos(solicitud)
                .then(mostrar)
                .catch(error);

            function mostrar(datos) {
                if (typeof datos == 'undefined') {
                    throw new Error('Hay un error en el tipo de datos');
                }
                if (datos.length == 0) {
                    throw new Error('No hay datos para mostrar en la solicitud', { cause: solicitud });
                }
                ciudad.innerHTML = '';
                for (const dato of datos) {
                    const option = document.createElement('option');
                    option.value = dato.id;
                    option.innerHTML = dato.nombre;
                    ciudad.appendChild(option);
                }
                ciudad.disabled = false;

            } // funcion mostrar
        } // provincia.onchange

        function error(e) {
            console.table({ mensaje: e.message, solicitud: e.cause });
        } // funcion error
        // if provincia
    } 


} // onload