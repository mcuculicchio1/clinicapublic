document.addEventListener("DOMContentLoaded", function() {
    console.log("JavaScript para la página de consulta clínica cargado!");
});
function validarFormulario() {
    const paciente = document.getElementById('paciente').value;
    const profesional = document.getElementById('profesional').value;
    const descripcion = document.getElementById('descripcion').value;
    const etiquetas = document.getElementById('etiquetas').value;

    if (!paciente || paciente=="Paciente"|| !profesional || !descripcion || !etiquetas) {
        alert("Todos los campos son obligatorios.");
        return false;
    }else{
        alert("Consulta creada exitosamente.");
    }

    return true;
}