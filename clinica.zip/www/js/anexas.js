'use strict';

export async function solicitarDatos(solicitud) {
    try {
        const response = fetch('servicios/anexas.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(solicitud)
        });

        if (!response.ok) {
            throw new Error(`Error en la solicitud: ${response.statusText}`);
        }

        const datos = await response.json();
        if (!datos.exito) {
            throw new Error(`Error en la respuesta: ${datos.mensaje}`);
        }

        return datos.datos; // Accedemos a los datos directamente
    } catch (error) {
        console.error('Error en solicitarDatos:', error);
        throw error;
    }
}
