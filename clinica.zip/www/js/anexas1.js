'use strict';

export async function solicitarDatos(solicitud) {
   var datos = JSON.stringify(solicitud); //stringify convierte un json a string

   var init = {
        method: 'POST',
        body: datos,
        headers: {
            'Accept': 'application/json',
             'Content-Type': 'application/json'
        }
    };

     init.body = datos; // datos para consulta

     var url = 'servicios/anexas.php'; // url del servicio
     var request = new Request(url, init);

     var response =  fetch(request) // fetch devuelve una promesa
                        .then(recuperar) // respuesta de la promesa
                        .then(devolver) // promesa de la respuesta
                        .catch(error); // captura de errores
        return response;
} // solicitarDatos                      

function recuperar(response) {
    if (!response.ok) 
        throw new Error('Error en la respuesta: ' + response.statusText);
    
    return response.json();
}

function devolver(dato) {
    if(dato){
        if(!dato.exito)
            throw new Error(dato.mensaje);
        return dato.datos;
    }else{
        throw new Error('anda pero hay error en los datos');
    }
}

function error(e) {
    console.table(e);
}