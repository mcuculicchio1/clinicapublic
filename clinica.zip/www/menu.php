<?php

use App\Lib\Page;
use App\Session;


?>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo Page::set(); ?>">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo Page::set('testDao');?>">Test</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo Page::set('historia_clinica');?>">Historia Clinica</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Historias Clinicas
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?php echo Page::set('historia_clinica_create');?>">Agregar Historia Clinica</a></li>
            <li><a class="dropdown-item" href="<?php echo Page::set('historia_clinica_select'); ?>">Consultar Historia Clinica</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Actualizar Historia Clinica</a></li>
          </ul>
          
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pacientes
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?php echo Page::set('alta_paciente');?>">Agregar Paciente</a></li>
            <li><a class="dropdown-item" href="#">Consultar Paciente</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Actualizar Paciente</a></li>
          </ul>
          
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo Page::set('logout');?>">Logout</a>
        
      </ul>
      <?php 
      $session = new Session();
      if($session->get('nombre'))
      echo "Usuario {$session->get('nombre')}";
      ?>
      
    </div>
  </div>
</nav>

