<?php
require '../App/autoload.php';
require '../App/Config.php';

use App\Dao\Dao_anexa;
use App\Lib\Log;

$datos = [];
$jsondata = [];
$exito = true;
$mensaje = "";
$filtro = [];

try {
    $post = json_decode(file_get_contents('php://input'), true);  // Decodificar como array asociativo

    if (isset($post) && isset($post['tabla'])) {
        if (isset($post['filtro'])) {
            $filtro = $post['filtro'];
        } else {
            $filtro = [];
        }

        try {
            switch ($post['tabla']) {
                case "paises":
                    $datos = Dao_anexa::get_paises();
                    break;
                case "provincias":
                    if (isset($filtro['pais'])) {
                        $datos = Dao_anexa::get_provincias($filtro['pais']);

                    } else {
                        throw new Exception("Filtro 'pais' no definido para la tabla 'provincias'");
                    }
                    break;
                case "ciudades":
                    if (isset($filtro['provincia'])) {
                        $datos = Dao_anexa::get_ciudades($filtro['provincia']);
                    } else {
                        throw new Exception("Filtro 'provincia' no definido para la tabla 'ciudades'");
                    }
                    break;
                case "obras_sociales":
                    $datos = Dao_anexa::get_obras_sociales();
                    break;
                case "tipos_documento":
                    $datos = Dao_anexa::get_tipos_documento();
                    break;
                default:
                    throw new Exception("Tabla no definida: " . $post['tabla']);
            }
        } catch (Exception $e) {
            $exito = false;
            $mensaje = "Error al recuperar datos de la tabla {$post['tabla']} con el filtro: " . json_encode($filtro);
            throw $e;
        }
    } else {
        $exito = false;
        $mensaje = "No se recibieron datos o la tabla no está definida";
        throw new Exception($mensaje, ERROR);
    }
} catch (Exception $e) {
    $tipo = 'ERROR';
    Log::grabar("[$tipo]". PHP_EOL . $mensaje . PHP_EOL . $e->getMessage());
} finally {
    if ($exito) {
        Log::grabar("[SERVICIO]". PHP_EOL . $mensaje . PHP_EOL . json_encode($post));
    }

    $jsondata['exito'] = $exito;
    $jsondata['mensaje'] = $mensaje;
    $jsondata['datos'] = $datos;

    header('Content-type: application/json; charset=utf-8');
    echo json_encode($jsondata);
}
?>
