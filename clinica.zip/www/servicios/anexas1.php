<?php
require '../App/autoload.php';
require '../App/Config.php';

use App\Dao\Dao_anexa;
use App\Lib\Log;

$datos = [];  //devuelve datos de la consulta
$jsondata = []; //array para devolver en formato json
$exito = true; //controlar si hubo errores
$mensaje = ""; //mensaje de error o log
$filtro = []; //filtro 

file_put_contents('logerror.log',$datos,FILE_APPEND);
try {
    $post = json_decode(file_get_contents('php://input'), false);
    if(isset($post)){
        if(isset($post->tabla)){
            if(isset($post->filtro))
                $filtro = json_decode(json_encode($post->filtro), true);
            else{
                $exito = false;
                $mensaje = "Tabla no definida";
            }

        }

        if($exito){
            try{
                switch($post->tabla){
                    case "paises":
                        $datos = Dao_anexa::get_paises($filtro);
                        break;
                    case "provincias":
                        $datos = Dao_anexa::get_provincias($filtro);
                        break;
                    case "ciudades":
                        $datos = Dao_anexa::get_ciudades($filtro);
                        break;
                    case "obras_sociales":
                        $datos = Dao_anexa::get_obras_sociales($filtro);
                        break;
                    case "tipos_documento":
                        $datos = Dao_anexa::get_tipos_documento();
                        break;
                    default:
                        $exito = false;
                        $mensaje = "Tabla no definida";
                        break;
                }
        }
        catch(Exception $e){
            $exito = false;
            $mensaje = "Error al recuperar datos de la tabla $post->tabla con el filtro: ".json_encode($filtro);
            throw $e;
        }

    }
}
else{
    $exito = false;
    $mensaje = "No se recibieron datos";
    throw new Exception($mensaje, ERROR);
}
}
catch(Exception $e){
    $tipo = '';
    switch($e->getCode()){
        case ERROR:
            $tipo = 'ERROR';
            break;
        case DEBUG:
            $tipo = 'DEBUG';
            break;
        case INFO:
            $tipo = 'INFO';
            break;
        default:
            $tipo = 'INFO';
            break;
    }
    Log::grabar("[$tipo]".PHP_EOL.$mensaje.PHP_EOL.$e->getMessage());
}
finally{
    if($exito)
    Log::grabar("[SERVICIO]".PHP_EOL.$mensaje.PHP_EOL.json_encode($post));
    $jsondata['exito'] = $exito;
    $jsondata['mensaje'] = $mensaje;
    $jsondata['datos'] = $datos;
    
    header('Content-type: application/json; charset=utf-8');
    echo json_encode($jsondata);
    file_put_contents('logerror.log',$jsondata,FILE_APPEND);
}



