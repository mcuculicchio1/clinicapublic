<?php

require_once('../../App/Config.php');

use App\Lib\Log;

Log::set_archivo_log('../../App/Log/'.ARCHIVOLOG);


