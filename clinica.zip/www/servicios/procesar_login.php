<?php

require 'config.php';

use App\Dao\Dao_usuario;
use App\Lib\Log;
use App\Session;



if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['usuario'];
    $pass = $_POST['contraseña'];

    try {
        // Verificar las credenciales del usuario
        $usuario = Dao_usuario::get_usuario($user);
        
       

        if ($usuario && $pass === $usuario['password']) {
            $sesion = new Session();
            // Credenciales correctas, establecer la sesión
            $sesion->set('nombre', $usuario['nombre']);
            $sesion->set('login', true);
            echo "Usuario logueado";
            // Redirigir al usuario a la página principal
            
            header("refresh:2;url=../index.php");
            
            exit;
        } else {
            // Credenciales incorrectas, mostrar mensaje de error
            $mensaje = "Usuario o contraseña incorrectos.";
             echo $mensaje.PHP_EOL;
             header("refresh:2;url=../index.php?p=login");
            // echo "<a href='login.php'>Volver</a>";
            // echo $usuario['password'];
            // echo $pass;

        }
    } catch (Exception $e) {
        $mensaje = "Ocurrió un error al intentar iniciar sesión.";
        Log::grabar("[ERROR]". PHP_EOL . $mensaje . PHP_EOL . $e->getMessage());
    }
   
}
?>

