<?php

require_once('../App/autoload.php');
use \App\Dao\db;
//db::get_conexion();

//db::ejecutar("SELECT * FROM ciudades limit 10;");

//$r = db::ejecutar("UPDATE perfiles SET nombre='Admin' WHERE id=1;");
//var_dump($r);
//echo "<br>";

$r = db::ejecutar("SELECT * FROM perfiles;");
$r = db::get_datos();
print_r($r);

//$sdao = dao_usuarios::nuevo(['usuario'=>'admin', 'password'=>password_hash('admin.2024', null), 'nombre'=>'Administrador', 'perfil'=>1]);
//if($sdao)
//    echo 'Se inserto';
//else
//    echo 'Error';



/*$exito = db::ejecutar("SELECT pa.nombre pais, pr.nombre as prov FROM provincias pr, paises pa WHERE pr.nombre like '%rio%' and pr.pais=pa.id;");
if(!$exito)
    echo 'Error en la consulta';
$d = db::get_datos();
echo "<pre>";
print_r($d);
echo "</pre>";

echo "<h1>".$d[3]['pais']."</h1>";
*/

/*
$passw =  password_hash('usuario.clinica', null);
echo "<br>";
if(password_verify('usuario.linica', $passw))
    echo 'Correcta';
else
    echo 'Incorreta';
*/
/*
$u['nombre']='Superman';
$u['usuario']='super';
$u['clave']=password_hash('super.2024', null);
$u['perfil']=2;
*/
/*
$u['nombre']='Spiderrman';
$u['usuario']='spider';
$u['clave']=password_hash('spider.2024', null);
$u['perfil']=2;

$exito = dao_usuarios::nuevo($u);
if($exito)
    echo 'Se inserto';
else
    echo 'Error';
*/
/*
$f['nombre'] = 'Spiderrman';
$f['usuario'] = 'spider';
$d = dao_usuarios::get_datos($f);
*/
//$d = dao_usuarios::get_datos(['usuario'=>'spider', 'nombre'=>'Spiderrman']);
//$d = dao_usuarios::get_datos(['perfil'=>'1']);
//echo "<pre>";
//print_r($d);
//echo "</pre>";

//echo dao_usuarios::get_perfil('spider');
